<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade script for transcript plugin
 *
 * @package   gradereport_transcript
 * @copyright 2025 COR4EDU
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade function for transcript plugin
 *
 * @param int $oldversion The old version of the plugin
 * @return bool True on success
 */
function xmldb_gradereport_transcript_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    // Upgrade to version 2025101902 - Add flexible hour types.
    if ($oldversion < 2025101902) {

        // Add clinicalhours column to courses table.
        $table = new xmldb_table('gradereport_transcript_courses');
        $field = new xmldb_field('clinicalhours', XMLDB_TYPE_NUMBER, '10, 2', null, null, null, '0', 'labhours');

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add hour label columns to programs table.
        $table = new xmldb_table('gradereport_transcript_programs');

        // Hour 1 label (Theory Hours).
        $field = new xmldb_field('hour1label', XMLDB_TYPE_CHAR, '50', null, null, null, 'Theory Hours', 'gradescaleid');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Hour 2 label (Lab Hours).
        $field = new xmldb_field('hour2label', XMLDB_TYPE_CHAR, '50', null, null, null, 'Lab Hours', 'hour1label');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Hour 3 label (Clinical Hours).
        $field = new xmldb_field('hour3label', XMLDB_TYPE_CHAR, '50', null, null, null, 'Clinical Hours', 'hour2label');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Transcript savepoint reached.
        upgrade_plugin_savepoint(true, 2025101902, 'gradereport', 'transcript');
    }

    // Upgrade to version 2025101915 - Reset capabilities to apply new context levels.
    if ($oldversion < 2025101915) {

        // Update capabilities from db/access.php.
        // This applies capability definitions (including context levels) from db/access.php
        // and re-applies archetype defaults to standard roles (Student, Teacher, etc.)
        update_capabilities('gradereport_transcript');

        // Transcript savepoint reached.
        upgrade_plugin_savepoint(true, 2025101915, 'gradereport', 'transcript');
    }

    // Upgrade to version 2025101925 - Phase 6.1: Request/Payment System.
    if ($oldversion < 2025101925) {

        // Define table gradereport_transcript_pricing to be created.
        $table = new xmldb_table('gradereport_transcript_pricing');

        // Adding fields to table gradereport_transcript_pricing.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('schoolid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('firstfree', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '1');
        $table->add_field('officialprice', XMLDB_TYPE_NUMBER, '10, 2', null, null, null, '0.00');
        $table->add_field('unofficialprice', XMLDB_TYPE_NUMBER, '10, 2', null, null, null, '0.00');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Adding keys to table gradereport_transcript_pricing.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('schoolid', XMLDB_KEY_FOREIGN, ['schoolid'], 'gradereport_transcript_schools', ['id']);

        // Note: Foreign key automatically creates an index, no need for explicit index.
        // Each school should have only one pricing record (enforced at application level).

        // Conditionally launch create table for gradereport_transcript_pricing.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Define fields to be added to gradereport_transcript_requests.
        $table = new xmldb_table('gradereport_transcript_requests');

        // Add recipientname field (institution/company name).
        $field = new xmldb_field('recipientname', XMLDB_TYPE_CHAR, '255', null, null, null, null, 'recipientaddress');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add recipientphone field.
        $field = new xmldb_field('recipientphone', XMLDB_TYPE_CHAR, '50', null, null, null, null, 'recipientname');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add price field.
        $field = new xmldb_field('price', XMLDB_TYPE_NUMBER, '10, 2', null, null, null, '0.00', 'notes');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add paymentstatus field.
        $field = new xmldb_field('paymentstatus', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'pending', 'price');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add paymentmethod field.
        $field = new xmldb_field('paymentmethod', XMLDB_TYPE_CHAR, '20', null, null, null, null, 'paymentstatus');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add invoicenumber field.
        $field = new xmldb_field('invoicenumber', XMLDB_TYPE_CHAR, '50', null, null, null, null, 'paymentmethod');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add invoicedate field.
        $field = new xmldb_field('invoicedate', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'invoicenumber');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add paiddate field.
        $field = new xmldb_field('paiddate', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'invoicedate');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Transcript savepoint reached.
        upgrade_plugin_savepoint(true, 2025101925, 'gradereport', 'transcript');
    }

    // Upgrade to version 2025101926 - Phase 6.2: Add delivery tracking fields.
    if ($oldversion < 2025101926) {

        // Define table gradereport_transcript_requests to be updated.
        $table = new xmldb_table('gradereport_transcript_requests');

        // Add deliverystatus field.
        $field = new xmldb_field('deliverystatus', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'pending', 'paiddate');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add deliverydate field.
        $field = new xmldb_field('deliverydate', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'deliverystatus');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add deliverynotes field.
        $field = new xmldb_field('deliverynotes', XMLDB_TYPE_TEXT, null, null, null, null, null, 'deliverydate');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add trackingnumber field.
        $field = new xmldb_field('trackingnumber', XMLDB_TYPE_CHAR, '100', null, null, null, null, 'deliverynotes');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add receiptnumber field.
        $field = new xmldb_field('receiptnumber', XMLDB_TYPE_CHAR, '100', null, null, null, null, 'trackingnumber');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add paymentnotes field.
        $field = new xmldb_field('paymentnotes', XMLDB_TYPE_TEXT, null, null, null, null, null, 'receiptnumber');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Transcript savepoint reached.
        upgrade_plugin_savepoint(true, 2025101926, 'gradereport', 'transcript');
    }

    // Upgrade to version 2025102207 - Add program completion dates for official transcripts.
    if ($oldversion < 2025102207) {

        // Define table gradereport_transcript_requests to be updated.
        $table = new xmldb_table('gradereport_transcript_requests');

        // Add programstartdate field.
        $field = new xmldb_field('programstartdate', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'approvaldate');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add completionstatus field.
        $field = new xmldb_field('completionstatus', XMLDB_TYPE_CHAR, '20', null, null, null, null, 'programstartdate');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add graduationdate field.
        $field = new xmldb_field('graduationdate', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'completionstatus');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add withdrawndate field.
        $field = new xmldb_field('withdrawndate', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'graduationdate');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Transcript savepoint reached.
        upgrade_plugin_savepoint(true, 2025102207, 'gradereport', 'transcript');
    }

    // Upgrade to version 2025102500 - Add transfer credits and custom grading scales.
    if ($oldversion < 2025102500) {

        // Define table gradereport_transcript_transfer to be created.
        $table = new xmldb_table('gradereport_transcript_transfer');

        // Adding fields to table gradereport_transcript_transfer.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('programid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('coursecode', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL, null, null);
        $table->add_field('coursename', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
        $table->add_field('grade', XMLDB_TYPE_CHAR, '10', null, null, null, null);
        $table->add_field('credits', XMLDB_TYPE_NUMBER, '10, 2', null, null, null, '0');
        $table->add_field('hours', XMLDB_TYPE_NUMBER, '10, 2', null, null, null, '0');
        $table->add_field('transfersymbol', XMLDB_TYPE_CHAR, '10', null, null, null, 'T');
        $table->add_field('institution', XMLDB_TYPE_CHAR, '255', null, null, null, null);
        $table->add_field('sortorder', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Adding keys to table gradereport_transcript_transfer.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('programid', XMLDB_KEY_FOREIGN, ['programid'], 'gradereport_transcript_programs', ['id']);

        // Adding indexes to table gradereport_transcript_transfer.
        $table->add_index('userid', XMLDB_INDEX_NOTUNIQUE, ['userid']);
        $table->add_index('userid_program', XMLDB_INDEX_NOTUNIQUE, ['userid', 'programid']);

        // Conditionally launch create table for gradereport_transcript_transfer.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Define table gradereport_transcript_gradescale to be created.
        $table = new xmldb_table('gradereport_transcript_gradescale');

        // Adding fields to table gradereport_transcript_gradescale.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('schoolid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('lettergrade', XMLDB_TYPE_CHAR, '5', null, XMLDB_NOTNULL, null, null);
        $table->add_field('minpercentage', XMLDB_TYPE_NUMBER, '5, 2', null, null, null, '0');
        $table->add_field('maxpercentage', XMLDB_TYPE_NUMBER, '5, 2', null, null, null, '0');
        $table->add_field('gradepoints', XMLDB_TYPE_NUMBER, '3, 2', null, null, null, '0');
        $table->add_field('quality', XMLDB_TYPE_CHAR, '50', null, null, null, null);
        $table->add_field('sortorder', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Adding keys to table gradereport_transcript_gradescale.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('schoolid', XMLDB_KEY_FOREIGN, ['schoolid'], 'gradereport_transcript_schools', ['id']);

        // Adding indexes to table gradereport_transcript_gradescale.
        $table->add_index('school_sort', XMLDB_INDEX_NOTUNIQUE, ['schoolid', 'sortorder']);

        // Conditionally launch create table for gradereport_transcript_gradescale.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Define table gradereport_transcript_symbols to be created.
        $table = new xmldb_table('gradereport_transcript_symbols');

        // Adding fields to table gradereport_transcript_symbols.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('schoolid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('symbol', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('meaning', XMLDB_TYPE_TEXT, null, null, XMLDB_NOTNULL, null, null);
        $table->add_field('sortorder', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Adding keys to table gradereport_transcript_symbols.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('schoolid', XMLDB_KEY_FOREIGN, ['schoolid'], 'gradereport_transcript_schools', ['id']);

        // Adding indexes to table gradereport_transcript_symbols.
        $table->add_index('school_sort', XMLDB_INDEX_NOTUNIQUE, ['schoolid', 'sortorder']);

        // Conditionally launch create table for gradereport_transcript_symbols.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create default grading scales and symbols for existing schools.
        $schools = $DB->get_records('gradereport_transcript_schools');
        foreach ($schools as $school) {
            gradereport_transcript_create_default_gradescale($school->id);
            gradereport_transcript_create_default_symbols($school->id);
        }

        // Transcript savepoint reached.
        upgrade_plugin_savepoint(true, 2025102500, 'gradereport', 'transcript');
    }

    // Upgrade to version 2025102510 - Add detailed hour fields to transfer credits.
    if ($oldversion < 2025102510) {

        // Define table gradereport_transcript_transfer to be updated.
        $table = new xmldb_table('gradereport_transcript_transfer');

        // Add theoryhours field.
        $field = new xmldb_field('theoryhours', XMLDB_TYPE_NUMBER, '10, 2', null, null, null, '0', 'hours');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add labhours field.
        $field = new xmldb_field('labhours', XMLDB_TYPE_NUMBER, '10, 2', null, null, null, '0', 'theoryhours');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add clinicalhours field.
        $field = new xmldb_field('clinicalhours', XMLDB_TYPE_NUMBER, '10, 2', null, null, null, '0', 'labhours');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Transcript savepoint reached.
        upgrade_plugin_savepoint(true, 2025102510, 'gradereport', 'transcript');
    }

    // Upgrade to version 2025102511 - Add course equivalency mapping table.
    if ($oldversion < 2025102511) {

        // Define table gradereport_transcript_equivalency to be created.
        $table = new xmldb_table('gradereport_transcript_equivalency');

        // Adding fields to table gradereport_transcript_equivalency.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('transferid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('programid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Adding keys to table gradereport_transcript_equivalency.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('transferid', XMLDB_KEY_FOREIGN, ['transferid'], 'gradereport_transcript_transfer', ['id']);
        $table->add_key('courseid', XMLDB_KEY_FOREIGN, ['courseid'], 'course', ['id']);
        $table->add_key('programid', XMLDB_KEY_FOREIGN, ['programid'], 'gradereport_transcript_programs', ['id']);

        // Adding indexes to table gradereport_transcript_equivalency.
        $table->add_index('userid', XMLDB_INDEX_NOTUNIQUE, ['userid']);
        $table->add_index('user_program', XMLDB_INDEX_NOTUNIQUE, ['userid', 'programid']);
        $table->add_index('transfer_course', XMLDB_INDEX_UNIQUE, ['transferid', 'courseid']);

        // Conditionally launch create table for gradereport_transcript_equivalency.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Transcript savepoint reached.
        upgrade_plugin_savepoint(true, 2025102511, 'gradereport', 'transcript');
    }

    // Upgrade to version 2025102514 - v1.0.20: Headers, footers, verification section, date format.
    if ($oldversion < 2025102514) {
        // No schema changes - only code improvements.
        // - Removed signature/seal footer section
        // - Added TCPDF header/footer with school branding and page numbers
        // - Moved verification code to Page 2 with URL
        // - Fixed American date format on verification page
        upgrade_plugin_savepoint(true, 2025102514, 'gradereport', 'transcript');
    }

    // Upgrade to version 2025102515 - v1.0.21: Fixed TCPDF implementation.
    if ($oldversion < 2025102515) {
        // No schema changes - only code improvements.
        // - Created transcript_pdf.php class extending pdf
        // - Properly overrode Header() and Footer() methods
        // - Fixed invalid setHeaderCallback/setFooterCallback usage
        upgrade_plugin_savepoint(true, 2025102515, 'gradereport', 'transcript');
    }

    // Upgrade to version 2025102516 - v1.0.22: Fixed method visibility and autoloading.
    if ($oldversion < 2025102516) {
        // No schema changes - only code improvements.
        // - Changed get_school_logo_path() and calculate_logo_dimensions() to public
        // - Removed manual require for transcript_pdf.php (uses Moodle autoloading)
        upgrade_plugin_savepoint(true, 2025102516, 'gradereport', 'transcript');
    }

    return true;
}

/**
 * Create default grading scale for a school
 *
 * Creates standard US 4.0 grading scale with A-F grades.
 * Called during initial school creation or upgrade migration.
 *
 * @param int $schoolid School ID
 */
function gradereport_transcript_create_default_gradescale($schoolid) {
    global $DB;

    // Check if school already has a grading scale.
    $existing = $DB->count_records('gradereport_transcript_gradescale', ['schoolid' => $schoolid]);
    if ($existing > 0) {
        return; // School already has a custom scale.
    }

    // Standard US grading scale (4.0 GPA system).
    $grades = [
        ['lettergrade' => 'A', 'minpercentage' => 90, 'maxpercentage' => 100, 'gradepoints' => 4.0, 'quality' => 'Excellent', 'sortorder' => 1],
        ['lettergrade' => 'B', 'minpercentage' => 80, 'maxpercentage' => 89, 'gradepoints' => 3.0, 'quality' => 'Good', 'sortorder' => 2],
        ['lettergrade' => 'C', 'minpercentage' => 70, 'maxpercentage' => 79, 'gradepoints' => 2.0, 'quality' => 'Satisfactory', 'sortorder' => 3],
        ['lettergrade' => 'D', 'minpercentage' => 60, 'maxpercentage' => 69, 'gradepoints' => 1.0, 'quality' => 'Poor', 'sortorder' => 4],
        ['lettergrade' => 'F', 'minpercentage' => 0, 'maxpercentage' => 59, 'gradepoints' => 0.0, 'quality' => 'Failing', 'sortorder' => 5],
    ];

    $timenow = time();

    foreach ($grades as $grade) {
        $record = (object)[
            'schoolid' => $schoolid,
            'lettergrade' => $grade['lettergrade'],
            'minpercentage' => $grade['minpercentage'],
            'maxpercentage' => $grade['maxpercentage'],
            'gradepoints' => $grade['gradepoints'],
            'quality' => $grade['quality'],
            'sortorder' => $grade['sortorder'],
            'timecreated' => $timenow,
            'timemodified' => $timenow,
        ];

        $DB->insert_record('gradereport_transcript_gradescale', $record);
    }
}

/**
 * Create default symbols/notations for a school
 *
 * Creates standard academic symbols (W, I, T, P, AU, IP).
 * Called during initial school creation or upgrade migration.
 *
 * @param int $schoolid School ID
 */
function gradereport_transcript_create_default_symbols($schoolid) {
    global $DB;

    // Check if school already has symbols.
    $existing = $DB->count_records('gradereport_transcript_symbols', ['schoolid' => $schoolid]);
    if ($existing > 0) {
        return; // School already has custom symbols.
    }

    // Standard academic symbols.
    $symbols = [
        ['symbol' => 'W', 'meaning' => 'Withdrawn - Student officially withdrew from the course', 'sortorder' => 1],
        ['symbol' => 'I', 'meaning' => 'Incomplete - Coursework not completed within the term', 'sortorder' => 2],
        ['symbol' => 'T', 'meaning' => 'Transfer Credit - Credit earned at another institution', 'sortorder' => 3],
        ['symbol' => 'P', 'meaning' => 'Pass - Credit earned in pass/fail course', 'sortorder' => 4],
        ['symbol' => 'AU', 'meaning' => 'Audit - Course taken for no credit', 'sortorder' => 5],
        ['symbol' => 'IP', 'meaning' => 'In Progress - Course currently being taken', 'sortorder' => 6],
    ];

    $timenow = time();

    foreach ($symbols as $symboldata) {
        $record = (object)[
            'schoolid' => $schoolid,
            'symbol' => $symboldata['symbol'],
            'meaning' => $symboldata['meaning'],
            'sortorder' => $symboldata['sortorder'],
            'timecreated' => $timenow,
            'timemodified' => $timenow,
        ];

        $DB->insert_record('gradereport_transcript_symbols', $record);
    }
}
